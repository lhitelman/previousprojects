package project3;

import java.io.File;
import java.lang.Integer;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;



/**
 * This class converts the file of movie locations into various arrays and objects.
 * The program is interactive.
 * When the program is executed the name of the input file containing the list of all the movies filmed 
 * in San Francisco and their locations is provided as the program's single command line argument. 
 * The data in this file serves as a database of all the movies, locations, actors, writer, director, and fun facts. 
 * In the interactive part, the user enters a title or actor keyword. The program 
 * responds by printing the movie description and locations and other included information.
 * 
 * @author Lily Hitelman
 * @version 10/19/18
 * 
 */

public class SFMovieData {
	
	
	/**
	 * The main method of this program contains the functions that open and read the SFMovies
	 * data and put the information into movie, actor, and location objects. It also holds the 
	 * interactive part of the program, which asks the user for a keyword that will search either an actor 
	 * or a title. The first string should be the name of the input file containing the list of movies. 
	 */
	public static void main (String [] args) {
		
		
		//verify that a command line argument exists 
		if (args.length == 0 ) {
			System.err.println("Error: the program requires a file name as an argument.\n");
			System.exit(1);
		}
		
		//verify that the file in the command line argument exists
		File SFMovies = new File(args[0]); 
		
		if (!SFMovies.exists()){
			System.err.println("Error: the file " + SFMovies.getAbsolutePath()+ " does not exist.\n");
		}
		if (!SFMovies.canRead()){
			System.err.println("Error: the file "+SFMovies.getAbsolutePath()+
											" cannot be read.\n");
		}
				
				

				
		//open and read the file
		Scanner inMovies = null; 
		try {
			inMovies = new Scanner (SFMovies, "UTF-8");
			
		} 
		catch (FileNotFoundException e) {
			System.err.println("File cannot be found.");
		}
		
		
		
		//put the info into movies
		MovieList list = new MovieList();	

		Movie current = null;
		

		ArrayList<String> movieData = new ArrayList<>();
	
		
		while (inMovies.hasNextLine()) {
			movieData = splitCSVLine(inMovies.nextLine()); 
			
			//set all to null
			String title = null;
			String stringYear = null;
			String location = null;
			String funFacts = null;
			String director = null;
			String writer = null;
			Actor actor1 = null;
			Actor actor2 = null;
			Actor actor3 = null;
				
			try { 
				//if there are all/most objects
				if (movieData.size() >= 9) {
					if (movieData.size() == 11 && movieData.get(10).trim().isEmpty())
						actor3 = null;
					else if (movieData.size() == 11)
						actor3 = new Actor (movieData.get(10).trim());	
					
					if (movieData.size() >= 10 && movieData.get(9).trim().isEmpty())
						actor2 = null;
					else
						actor2 = new Actor (movieData.get(9).trim());
					
					if (movieData.get(8).trim().isEmpty())
						//if there's no actor1, it is invalid
						continue;
					else {
						actor1 = new Actor (movieData.get(8).trim());
						title = movieData.get(0);
						stringYear = movieData.get(1);
						int year = Integer.parseInt(stringYear);
						location = movieData.get(2);
						funFacts = movieData.get(3);
						director = movieData.get(6);
						writer = movieData.get(7);
						
						//make a new movie
						current = new Movie(title, year, director, writer, 
								actor1, actor2, actor3);
						boolean exists = false;
						//or if it already exists, add a location
						for (Movie m: list) {
							if (current.equals(m)) {
								exists = true;
								Location newLoc = new Location (location, funFacts);
								m.addLocation(newLoc);
							}
						}
						if (!exists) {
							Location newLoc = new Location (location, funFacts);
							current.addLocation(newLoc);
							list.add(current);	
						}
					}
						
					
				} else {
					continue;
				}
				
			} catch (IllegalArgumentException ex) {
				
			}
		}
		inMovies.close();
	

		
		
		
		
		
		//user input section
		Scanner userInput = new Scanner (System.in ); 
		String type = "";
		String word = "";
		
		//print header
		System.out.println("Search the database by matching keywords to titles or actor names.\n"
				+ "\tTo search for matching titles, enter\n\t\ttitle KEYWORD\n"
				+ "\tTo search for matching actor names, enter\n\t\tactor KEYWORD\n"
				+ "\tTo finish the program, enter\n\t\tquit\n\n\n\n");	
		
		do {
			System.out.println("Enter your search query: \n");
			type = userInput.next();
			word = userInput.nextLine().trim();

			if (type.equalsIgnoreCase("quit"))
				break;
			else { 
				//if they want to search a title
				if (type.equalsIgnoreCase("title")){			
					MovieList result = list.getMatchingTitles( word );
					if (result == null) {
						System.out.println("No matches found. Try again.");
					}
					else {
						for(Movie m: result) {
							System.out.println(m);	
						}
						
					}
				
				} 
				//if they want to search an actor				
				else if (type.equalsIgnoreCase("actor")){
					MovieList result = list.getMatchingActor ( word );
					if (result == null) {
						System.out.println("\nNo matches found. Try again.\n");
					}
					else {
						for(Movie m: result) {
							System.out.println(m);
						}
					
					}
				
				}
				//if they try to enter another option	
				else {
					System.out.println("This is not a valid query. Try again."); 
					}
			}
			} while (!type.equalsIgnoreCase("quit")); 
			
	}

	//userInput.close();
	

		
		
//parse CSV file
/**
* Splits the given line of a CSV file according to commas and double quotes
* (double quotes are used to surround multi-word entries so that they may contain commas)
* @author Joanna Klukowska
* @param textLine  a line of text to be passed
* @return an Arraylist object containing all individual entries found on that line
*/
	public static ArrayList<String> splitCSVLine (String textLine){
		
		if (textLine == null ) 
			return null;
		
			ArrayList<String> entries = new ArrayList<String>(); 
			int lineLength = textLine.length();
			StringBuffer nextWord = new StringBuffer(); 
			char nextChar;
			boolean insideQuotes = false; 
			boolean insideEntry= false;
		
			// iterate over all characters in the textLine
			for (int i = 0; i < lineLength; i++) { 
				nextChar = textLine.charAt(i);
			
				// handle smart quotes as well as regular quotes
				if (nextChar == '"' || nextChar == '\u201C' || nextChar =='\u201D') {
						// change insideQuotes flag when nextChar is a quote 
						if (insideQuotes) {
							insideQuotes = false; 
							insideEntry = false;
						}else {
							insideQuotes = true;
							insideEntry = true; 
						}
				} else if (Character.isWhitespace(nextChar)) { 
					if ( insideQuotes || insideEntry ) {
					// add it to the current entry
						nextWord.append( nextChar );
					}else { // skip all spaces between entries 
						continue;
					}
				} else if ( nextChar == ',') {
					if (insideQuotes){ // comma inside an entry 
						nextWord.append(nextChar);
					} else { // end of entry found
						insideEntry = false; entries.add(nextWord.toString());
						nextWord = new StringBuffer(); 
					}
				} else {
					// add all other characters to the nextWord
					nextWord.append(nextChar); 
					insideEntry = true;
					}
				}
				// add the last word ( assuming not empty )
				// trim the white space before adding to the list 
				if (!nextWord.toString().equals("")) {
					entries.add(nextWord.toString().trim());
				}
				
				return entries;
		}

	
}










