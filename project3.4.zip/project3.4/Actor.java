package project3;

/** This class represents an Actor object. An actor object has a name. This class provides 
 * a constructor,getter and setter methods. 
 * @author Lily Hitelman
 * @version 10/19/2018
 */

public class Actor {
	
	//stores actor name
	private String actorName;
	
	/**
	 * Constructs a new actor object.
	 * @param name  - name of the actor.
	 * @throws IllegalArgumentException - if actor name is null or empty.
	 */
	public Actor (String name) throws IllegalArgumentException {
		setActorName(name);
	}
	
	
	
	/**
	 * This get method returns the private String variable of the actor's name.
	 * @return actorName - name of the actor object.
	 */
	public String getActorName() {
		return actorName;
	}

	
	
	/**
	 * This set method sets the actor's name to the variable given to the function.
	 * @param actorName - name for the actor object.
	 * @throws IllegalArgumentException - if the object is null or an empty string.
	 */
	public void setActorName(String actorName) throws IllegalArgumentException{
		actorName = actorName.trim(); 
		if (actorName == null || actorName.length() < 1 )
			throw new IllegalArgumentException("No Actor 1");
		else
			this.actorName = actorName;
	}

	
}











