package project3;

/** This class represents generic LinkedList objects. Linked lists are made of 
 * Node objects that have data and a reference to a next Node (or null if there
 * is no next object). The class provides private variables for the list's head, 
 * tail, and size. The class also provides two private internal classes for Node
 * objects and an Iterator. Methods include an iterator method, indexOf, 
 * get, a String method override, sort, add, remove, clear, contains, containsAll, 
 * isEmpty, an equals method override, isEmpty, and toArray.
 * 
 * @author Lily Hitelman
 * @version 10/20/2018
 */
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

public class LinkedList<E> implements Collection<E>, Iterable<E> {

	private Node head;
	private Node tail;
	private int size = 0;
	
	public LinkedList(){
		head = null;
	}
	
	
	
	/**
	 * This class provides nodes for the linked list. Node objects have data and 
	 * a reference to the next object in the linked list. This class provides 
	 * data fields and a constructor.
	 * @author lily
	 * @version 10/20/18
	 */
	private class Node {
		
		E data;
		Node next;
		
		//constructor
		Node(E data){
			this.data = data;
		}
		
	}
	

	/** 
	 * This method returns an instance of an iterator object.
	 * 
	 */
	@Override
	public Iter iterator() {
		Iter it = new Iter(this.head); 
		
		return it;
	}
	
	/**
	 * This class implements an iterator that iterates through a list.
	 * The class has a pointer variable, a hasNext method and a next method.
	 * @author lily
	 * @version 10/20/18
	 */
	private class Iter implements Iterator<E>{
		Node pointer;
		
		//constructor
		Iter(Node head) {
			pointer = head;
		}
		/**
		 * This method determines whether the current node has a reference to a
		 * next node or whether that reference is null.
		 */
		public boolean hasNext() {
			if (pointer!=null)
				return true;
			else
				return false;
		}
		/**
		 * This method returns the current node's data and moves the 
		 * pointer to the next node in the list.
		 */
		public E next () {
			E temp = pointer.data;
			pointer = pointer.next;
			return temp;
		}
	}
	
	
	
	/**
	 * This class returns the index of the first occurence of the 
	 * specified element in the list, or -1 if the list does not
	 * contain the element. 
	 * @param o - element to search for.
	 * @return int - representing the index of the first occurrence of the
	 * specified element in the list or -1 if the list doesn't contain the element.
	 */
	public int indexOf (Object o) {

		Node current = head;
		int index = 0;
		while (current.data != null) {
			if (current.data.equals(o))
				return index;
			if (current.next == null)
				return -1;
			current = current.next;
			index++;
		}
		return -1;
	} 
	
	
	
	/**
	 * This method returns the element at the specified position in this list.
	 * @param index - index of the element to return
	 * @return the element at the specified position in this list
	 * @throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index >= size)
	 */
	public E get (int index) {
		//if the index is beyond the size, don't look
		if (index >= this.size() || index < 0)
			throw new IndexOutOfBoundsException ();
		//search from head
		Node current = head;
		int counter = 0;
		while (counter <= index) {
			if (counter == index)
				return current.data;
			current = current.next;
			counter++;
		}
		return current.data;
	}
	
	
	
	/**
	 * Returns a string representation of this collection. The string representation
	 * consists of a list of the collection's elements in the order they are returned
	 * by its iterator, enclosed in square brackets. Adjacent elements are separated 
	 * by the characters ", ". Elements are converted to strings as by String.valueOf(Object).
	 * @return - a string representation of this collection
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < size(); i++) {
			sb.append(String.valueOf(get(i)));
			sb.append(", ");
		}
		return sb.toString();
	}
	
	
	
	/**
	 * This method sorts the elements in the collection.
	 */
	public void sort() {
		if(!this.isEmpty()) {
			Object [] array = toArray(); 
			Arrays.sort(array); 
			this.clear();
			for (Object o : array ) { 
				this.add( (E)o );
			}
		}
	}
	
	
	
	
	
	//methods from the collection interface
	
	/**
	 * This method ensures that the collection contains the 
	 * specified element.
	 * @param e
	 * @return boolean - true if the element has been added.
	 */
	public boolean add (E e) {
		if (head == null) {
			head = new Node (e);
			size++;
			return true;
		}
		
		//search from head
		Node current = head;
		
		//check if it exists
		while (current.next != null) {
			current = current.next;
		}
		
		//else add it to the tail
		current.next = new Node(e);
		tail = current.next;
		size++;
		return true;
	}
	
	
	/**
	 * This method removes a single instance of the specified element from this collection
	 * if it is present.
	 * @param o - an object to be removed from the list.
	 * @return boolean - returns true if the object is removed.
	 */
	public boolean remove (Object o) {
		//iterate through collection
		//if object is found, set a to c to remove b
		if (head == null)
			return false;
		if (head.data.equals(o)) {
			head = head.next;
			this.size--;
			return true;
		}
			
		Node current = head;
		while (current != null) {
				
			if (current.next.data.equals(o)) {
				if (current.next == tail) {
					current = tail;
					current.next = null;
					this.size--;
					return true;
				}
				current.next = current.next.next;
				this.size--;
				return true;
			}
			current = current.next;
		}
		return false;
	}
	
	
	
	/**
	 * This method removes all of the elements from this collection.
	 */
	public void clear() {
		this.head = null;
		size = 0;

	}
	
	

	/**
	 * This method checks whether the list contains the specified object and
	 * returns a boolean indicating whether it contains it or not. 
	 * @return boolean - true if the element is in the list, and false if not.
	 */
	@Override
	public boolean contains (Object o) {
		//iterate through elements in collection
		//return true if object is found
		//else return false
		Node current = head;
		while (current != null) {
			if (current.data.equals(o))
				return true;
			current = current.next;
		}
		return false;
	}
	
	/**
	 * This method checks to see if every element in the given collection c is in the list 
	 * it is called from. It returns true if the elements all exist, and false if not.
	 * @return boolean - true if all elements are contained in list, false if not.
	 */
	public boolean containsAll (Collection<?> c) {
		
		if (c == null) 
			return true;
		if (this.equals(c) || this == c)
			return true;
		
		if (c.getClass() != this.getClass())
			return false;
		
		Iterator<?> iter = c.iterator();
		while (iter.hasNext()) {
			if(!this.contains(iter.next()))
				return false;
		}
		return true;
	}
	
	
	/**
	 * This method compares the specified object with this collection for equality and
	 * returns a boolean.
	 * @return boolean - true if the collections are deemed equal, false if not.
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null) return false;
		if (o instanceof LinkedList<?>) {
			
			LinkedList<E> other = (LinkedList<E>)  o;
			if (this.size() == other.size()) {
				
				for (int a = 0; a < other.size(); a++) {
					if (!this.get(a).equals(other.get(a)))
						return false;
				}
				return true;
			}
		}
		return false;
	}
	
	
	/**
	 * This element checks to see if a list is empty or not. It returns
	 * a boolean.
	 * @return boolean - true if list is empty, false if not.
	 */
	
	public boolean isEmpty() {
		if (head == null)
			return true;
		else 
			return false;
	}
	
	
	
	/**
	 * This element checks the list's size.
	 * @return integer - returns an integer representing the list's size.
	 */
	public int size() {
		if (head == null)
			return 0;
		
		Node current = head;
		int count = 0;
		while (current != null) {
			count++;
			current = current.next;
			
		}
		
		if (this.size == count)
			return count;
		else {
			this.size = count;
			return count;
		}
			
				
	}
	
	
	
	
	/**
	 * This method returns an array containing all of the elements in this collection.
	 * @return Object [] - returns the new array.
	 */
	public Object [] toArray() {
		if (this.head == null)
			return null;
		int size = this.size();
		Object [] newarray = new Object [size];
		Node current = head;
		for (int i = 0; i < this.size(); i++) {
			newarray[i] = this.get(i);
			current = current.next;
		}
		return newarray;
		
	}
	
	
	
	
	/**
	 * This method returns an array containing all of the elements in the collection.
	 * The runtime type of the returned array is that of the specified array.
	 * @return T [] - returns the new array.
	 */
	public <T> T[] toArray (T[] a) {
		if (this.head == null)
			return null;
		if (a.length == this.size) {
			Node current = head;
			
			for (int i = 0; i < this.size(); i++) {
				a[i] = (T) this.get(i);
				current = current.next;
			}
		return a;
		}
		else {
			T [] newarray = (T []) new Object [this.size()];
			Node current = head;
			
			for (int i = 0; i < this.size(); i++) {
				newarray[i] = (T) this.get(i);
				current = current.next;
			}
		return newarray;
			
		}
	
		
	}
	

	/**
	 * This method's implementation is not required for project 3.
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) throws UnsupportedOperationException{
		// implementation not required for project 3
		return false;
	}

	/**
	 * This method's implementation is not required for project 3.
	 */
	@Override
	public boolean removeAll(Collection<?> c) throws UnsupportedOperationException{
		// implementation not required for project 3
		return false;
	}

	/**
	 * This method's implementation is not required for project 3.
	 */
	@Override
	public boolean retainAll(Collection<?> c) throws UnsupportedOperationException{
		// implementation not required for project 3
		return false;
	}



	
	
}
