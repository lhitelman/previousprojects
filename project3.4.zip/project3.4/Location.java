package project3;

/** This class represents Location objects. Locations must have a 
 * location description. Some locations have fun facts, but they are
 * optional. It provides a constructor, getter and setter methods.
 * @author Lily Hitelman
 * @version 10/19/2018
 */
public class Location {

	
	//stores location and fun facts
	private String location;
	private String funFacts;
	
	
	/**
	 * Constructs a new location by taking in a location and fun fact string. If fun facts exist for the location,
	 * it sets the fun facts, else it sets the fun fact to null.
	 * @param location - location where the movie was filmed.
	 * @param fun facts  - if applicable, takes a fun face about the location or null if not applicable.
	 * @throws IllegalArgumentException - if location is null or empty.
	 */
	public Location (String loc, String facts) throws IllegalArgumentException {
		setLocation(loc);
		setFunFacts(facts);
	}
	
	
	
	/**
	 * This get method returns the private String variable of the location.
	 * @return location - location where the movie was filmed.
	 */
	public String getLocation() {
		if (getFunFacts() != null)
			return location + " (" + getFunFacts() + ")";
		else
			return location;
	}
	
	
	
	
	
	/**
	 * This get method returns the private String variable of the fun facts.
	 * @return funFacts - fun facts about the location of filming.
	 */
	public String getFunFacts() {
		return funFacts;
	}

	
	
	
	/**
	 * This set method sets the location to the variable given to the function. The
	 * location cannot be null or an empty string.
	 * @param loc - location where the movie was filmed.
	 * @throws IllegalArgumentException - if null or empty string.
	 */
	public void setLocation(String loc) throws IllegalArgumentException {
		if (loc == null) 
			throw new IllegalArgumentException("Error: Location cannot be null.");
		if (loc.length() < 1)
			throw new IllegalArgumentException("The location cannot be empty.");
		
		this.location = loc;
		
	}
	
	
	
	
	
	/**
	 * This set method sets the fun facts to the variable given to the function. 
	 * Fun facts is allowed to be null or empty.
	 * @param facts - fun facts about the filming location
	 */
	public void setFunFacts(String facts){
		if (facts == null || facts.length() < 1)
			this.funFacts = null;
		else
			this.funFacts = facts;
		
	}
	

}
