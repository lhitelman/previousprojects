package project6;

import java.util.Iterator;

/** This class represents MovieList objects. MovieLists are binary search trees 
 * of Movie objects. The class provides a constructor, and two getter 
 * methods that return MovieList objects that contain a tree of movies that
 * contain actor names or titles that have the given string parameter in them. 
 * @author Lily Hitelman
 * @version 12/2/2018
 */
public class MovieList extends BST<Movie>{
	
	/**
	 * Constructor constructs a new MovieList object.
	 */
	public MovieList () {
		BST<Movie> ml = new BST<> ();
	}

	/**
	 * This method searches through the list from which the function is called
	 * to find titles that contain the given keyword. It returns a list of movie objects 
	 * whose titles contain the keyword as a substring.
	 * @param String keyword given by the user to search for titles that contain this keyword.
	 * @return MovieList a list of movies that have titles that contain the keyword.
	 */
	public MovieList getMatchingTitles (String keyword) {
		if (keyword == null || keyword.length() == 0 || this == null)
			return null;
		String keywordLower = keyword.toLowerCase();
		MovieList matchingTitles = new MovieList ();
		for (Movie m: this) {
			String title = m.getTitle();
			String titleLower = title.toLowerCase();
			if (titleLower.contains(keywordLower)) {
				matchingTitles.add(m);
			}
		}
		
		if (matchingTitles.size() == 0)
			return null;
		else
			return matchingTitles;
	}
	
	/**
	 * This method searches through the list from which the function is called
	 * to find actor names that contain the given keyword. It returns a list of movie 
	 * objects whose actors' names contain the keyword as a substring.
	 * @param String keyword given by the user, searches for movie actors containing this keyword
	 * @return MovieList a list of movies that contain actor names that contain the keyword
	 */
	public MovieList getMatchingActor (String keyword) {
		if (keyword == null || keyword.isEmpty() || this == null)
			return null;
		String keywordLower = keyword.toLowerCase();
		MovieList matchingActors = new MovieList ();
		for (Movie m: this) {
			
			String actor1 = m.getActor1();
			String actor2 = null;
			String actor2Lower = null;
			String actor3 = null;
			String actor3Lower = null;
			
			String actor1Lower = actor1.toLowerCase();
			if (actor1Lower.contains(keywordLower))
				matchingActors.add(m); 
			try {
				actor2 = m.getActor2();
				actor2Lower = actor2.toLowerCase();
				if(actor2Lower.contains(keywordLower))
					matchingActors.add(m);
			}catch (NullPointerException ex) {	
			}
			try {
				actor3 = m.getActor3();
				actor3Lower = actor3.toLowerCase();
				if(actor3Lower.contains(keywordLower))
					matchingActors.add(m);
			}catch (NullPointerException ep) {	
			}
		}
		return matchingActors;
	}
	
	
	
	
	/**
	 * This method overrides the default toString method. It returns
	 * a formatted string.
	 * @return String detailing the movie specifications.
	 */
	@Override
	public String toString() {
		//return a string containing a semicolon and a space separated list of the titles of the movie objects

		StringBuilder ts = new StringBuilder("");
		ts.append("\"");
		Iterator<Movie> itr = iterator();
		while (itr.hasNext()) {
			String title = itr.next().getTitle();
			ts.append(title);
			ts.append("; ");
		}
		ts.append("\"");

		return ts.toString();
	}
}
