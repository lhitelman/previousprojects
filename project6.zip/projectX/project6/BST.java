package project6;

import java.util.Collection;
import java.util.Stack;
import java.util.Iterator;
import java.util.NoSuchElementException;


/** This class represents generic Binary Search Tree objects. Binary search trees are made of 
 * Node objects that have data and a reference to two children nodes (or null if there
 * is no child object occupying the reference). The class provides private variables for the tree's 
 * root. The class also provides two private internal classes for Node objects and three iterators (pre, 
 * post, and in order). Other methods include get, a toString method override, toStringTreeFormat, ceiling,
 * clone, first, floor, higher, last, lower, add, remove, clear, contains, containsAll, isEmpty, equals, 
 * size, isEmpty, and toArray methods.
 * 
 * @author Lily Hitelman
 * @version 11/26/2018
 */
public class BST< E extends Comparable<E>> implements Collection<E>, Iterable<E> {

	//variables and constructor
	private BSTNode<E> root;
	private int size;
	private boolean found;
	
	public BST() {
		root = null;
		size = 0;
	}

	//node class
	/**
	 * This class provides nodes for the binary search tree. Node objects have data and 
	 * a reference to the left and right children in the binary search tree. This class 
	 * provides data fields and a constructor.
	 * @author Lily Hitelman
	 * @version 12/1/18
	 */
	private class BSTNode<E> {
		
		private E data;
		private BSTNode<E> left;
		private BSTNode<E> right;
		
		//constructor
		public BSTNode(E data){
			this.data = data;
			this.left = null;
			this.right = null;	
		}
		
	}


	//methods required
	/**
	 * This method returns the reference to the element stored in the tree with a value equal to the
	 * value passed as the parameter or null if no equal element exists in this tree. This method is a wrapper 
	 * method to an internal recursive method.
	 * @param value an element to search for in this tree
	 * @return E the reference to the element equal to the parameter value or null if no such element exists
	 */
	public E get (E value) {
		if (value == null)
			return null;
		return get(value, this.root);
	}
	/**
	 * This private internal method recurses on the tree until it finds the value given in the parameter
	 * or returns null if it cannot be found.
	 * @param value entered by the user to search for
	 * @param node root node of the tree to search through
	 * @return E reference to the element equal to the parameter value or null if no such element exists
	 */
	private E get(E value, BSTNode<E> node) {
		if (node.data.equals(value))
			//check current node
			return node.data;
		else if (value.compareTo(node.data) < 0 && node.left != null)
				//go left
				return get(value, node.left);
		else if (value.compareTo(node.data) > 0 && node.right != null)
				//go right
				return get(value, node.right);
		//else there's no match and return null
		return null;
	}
	/**
	 * Returns a string representation of this collection. The string representation
	 * consists of a list of the collection's elements in the order they are returned
	 * by its inorder iterator, enclosed in square brackets. Adjacent elements are separated 
	 * by the characters ", ". Elements are converted to strings as by String.valueOf(Object).
	 * @return a string representation of this collection
	 */
	@Override
	public String toString() {	
		
		StringBuilder tostr = new StringBuilder();
		tostr.append("[");
		Iterator<E> itr = iterator();
		while (itr.hasNext()) {
			tostr.append(String.valueOf(itr.next()));
			tostr.append(", ");
		}
		tostr.append("]");
		return tostr.toString();
	}
	/**
	 * Produces a string representation of the BST that resembles the look of a tree.
	 * @return String containing a tree-like representation of the BST
	 * @author Joanna Klukowska
	 */
	public String toStringTreeFormat() {
		StringBuilder s = new StringBuilder();
		preOrderPrint (root, 0, s);
		return s.toString();
	}
	/**
	 * Uses pre-order traversal to produce a tree-like representation of the BST.
	 * @param tree root node of the tree or the current subtree
	 * @param level (depth) of the current recursive call in the tree to determine the 
	 * indentation of each item
	 * @param output the string that accumulated the string representation of the BST
	 * @author Joanna Klukowska
	 */
	private void preOrderPrint (BSTNode<E> tree, int level, StringBuilder output) {
		if (tree != null) {
			String spaces = "\n";
			if (level > 0) {
				for (int i = 0; i < level - 1; i++)
					spaces += "   ";
				spaces += "|--";
			}
			output.append(spaces);
			output.append(tree.data);
			preOrderPrint(tree.left, level+1, output);
			preOrderPrint(tree.right, level+1, output);
		}
		else { //print the null children
			String spaces = "\n";
			if (level > 0) {
				for (int i = 0; i < level - 1; i++)
					spaces += "   ";
				spaces += "|--";
			}
			output.append(spaces);
			output.append("null");
		}
	}
	
	
	
	
	
	//iterator classes
	/**
	 * Returns an iterator over the elements in this collection. 
	 * The elements are returned in the order determined by the preorder
	 * traversal of the tree.
	 */
	public Iterator<E> preorderIterator() {
		return new PREIterator();
	}
	/**
	 * This private internal class implements the preorder iterator. It contains a constructor, a recursive preorder method
	 * that puts the tree on a stack, a hasNext method, and a next method.
	 */
	private class PREIterator implements Iterator<E> {
		BSTNode<E> current = root;
		Stack<BSTNode<E>> s = new Stack<BSTNode<E>>();
		
		public PREIterator() {
			preorder(current);
		}
		private void preorder(BSTNode<E> node) {
			if (node != null) {
				preorder(node.right);
				preorder(node.left);
				this.s.push(node);
			}
		}
		
		@Override
		public boolean hasNext() {
			return (!this.s.isEmpty());
		}
		
		@Override
		public E next() {
			if (!hasNext())
				throw new NoSuchElementException();
			return this.s.pop().data;
		}
		
		@Override
		public void remove() {
			throw new UnsupportedOperationException("Operation not supported for this iterator.");
		}
			
	}
	/**
	 * Returns an iterator over the elements in this collection. Elements
	 * are returned in the order determined by the postorder traversal.
	 */
	public Iterator<E> postorderIterator() {
		return new POSTIterator();
	}
	/**
	 * This private internal class implements the postorder iterator. It contains a constructor, a recursive postorder method
	 * that puts the tree on a stack, a hasNext method, and a next method.
	 */
	private class POSTIterator implements Iterator <E> {
		BSTNode<E> current = root;
		Stack<BSTNode<E>> s = new Stack<BSTNode<E>>();
		
		public POSTIterator() {
			postorder(current);
		}
		private void postorder(BSTNode<E> node) {
			if (node != null) {
				this.s.push(node);
				postorder(node.right);
				postorder(node.left);
				
			}
		}
		
		
		@Override
		public boolean hasNext() {
			return (!this.s.isEmpty());
		}
		@Override
		public E next() {
			if (!hasNext())
				throw new NoSuchElementException();
			return this.s.pop().data; 
		}
		@Override
		public void remove() {
			throw new UnsupportedOperationException("Operation not supported for this iterator.");
		}
	}
	/**
	 * Returns an iterator over the elements in this collection. Elements
	 * are returned in the order determined by the inorder traversal.
	 */
	public Iterator<E> iterator() {
		return new IOIterator();
	}
	/**
	 * This private internal class implements the inorder iterator. It contains a constructor, a recursive inorder method
	 * that puts the tree on a stack, a hasNext method, and a next method.
	 */
	private class IOIterator implements Iterator<E> {
			
		BSTNode<E> current = root;
		Stack<BSTNode<E>> s = new Stack<BSTNode<E>>();
			
		public IOIterator() {
			inorder(current);
		}
		private void inorder(BSTNode<E> node) {
			if (node != null) {
				inorder(node.right);
				this.s.push(node);
				inorder(node.left	);
			}
		}
		
		@Override
		public boolean hasNext() {
			return (!this.s.isEmpty());
		}
		
		@Override
		public E next() {
			if (!hasNext())
				throw new NoSuchElementException();
			return this.s.pop().data;
		}
		
		@Override
		public void remove() {
			throw new UnsupportedOperationException("Operation not supported for this iterator.");
		}
			
	}

	
	
	//TreeSet<E> methods
	/**
	 * Returns the least element in this set greater than or equal to the given element, 
	 * or null if there is no such element.
	 * @param e given element to compare to elements in the tree
	 * @return the least element in this set greater than or equal to the given element or 
	 * null if there is no such element
	 * @throws ClassCastException if the specified element cannot be compared with the elements currently in the set
	 * @throws NullPointerException if the specified element is null and this set uses natural ordering, or
	 * its comparator does not permit null elements
	 */
	public E ceiling (E e) {
		if (e == null || this.root == null)
			throw new NullPointerException ("The specified element is null; its comparator does not permit null elements.");
		if (e.getClass() != this.root.data.getClass())
			throw new ClassCastException ("The specified element cannot be compared with elements currently in the set.");
		else if (e.equals(root.data))
			return root.data;
		else
			return ceiling (e, this.root, this.root.data);
		
	}
	/**
	 * This private internal recursive method recurses through the tree to find the given element. It 
	 * also tracks the nodes traversed and keeps track of the current node that fits the requirements
	 * of the return data;
	 * @param e given element to compare to elements in the tree
	 * @param node the root of the tree or subtree to search through
	 * @param temp the reference of the current best fitting node
	 * @return the least element in this set greater than or equal to the given element or 
	 * null if there is no such element
	 */
	private E ceiling (E e, BSTNode<E> node, E temp) {
		if (e.equals(node.data))
			return node.data;
		
		//if node.data is closer to but still greater than temp replace temp
		if (e.compareTo(node.data) < 0 && e.compareTo(temp)< 0) {
			if (node.data.compareTo(temp) < 0)
				temp = node.data;
		}
		//if node.data is greater than e but temp isnt
		else if (e.compareTo(node.data) < 0 && e.compareTo(temp)> 0) {
				temp = node.data;
		}
		//go right if e is bigger than current node and current node has next
		if (e.compareTo(node.data) > 0) {
			if (node.right != null)
				return ceiling (e, node.right, temp);
			else if (e.compareTo(temp) < 0)
				return temp;
		}
		//go left if e is less than current node and current node has next
		if (e.compareTo(node.data) < 0) {
			if (node.left != null)
				return ceiling (e, node.left, temp);
			else if (e.compareTo(temp) < 0)
				return temp;
		}
		return null;
	}
	/**
	 * This method provides a shallow copy of this collection.
	 * @return a shallow copy of the collection
	 */
	public Object clone() {
		BST<E> clone = new BST<E>();
		Iterator<E> itr = preorderIterator();
		while (itr.hasNext()) {
			clone.add(itr.next());
		}
		return clone;
		
	}
	/**
	 * Returns the first (lowest) element currently in the tree.
	 * @return E reference to the lowest element in the tree
	 * @throws NoSuchElementException if the set is empty
	 */
	public E first() {
		if (this.root == null)
			throw new NoSuchElementException("This set is empty.");
		BSTNode<E> first = this.root;
		while (first.left != null) {
			first = first.left;
		}
		return first.data;
	}
	/**
	 * Returns the greatest element in this set less than or equal to the given element,
	 * or null if there is no such element. This public wrapper uses a private internal recursive function.
	 * @return E reference to the greatest element in the set less than or equal to the given element, 
	 * or null if there is no such element.
	 * @throws ClassCastException if the specified element cannot be compared with the elements currently in the set
	 * @throws NullPointerException if the specified element is null and this set uses natural ordering, or
	 * its comparator does not permit null elements
	 */
	public E floor(E e) {
		if (e == null || this.root == null)
			throw new NullPointerException ("The specified element is null; its comparator does not permit null elements.");
		if (e.getClass() != this.root.data.getClass())
			throw new ClassCastException ("The specified element cannot be compared with elements currently in the set.");
		else if (e.equals(root.data))
			return root.data;
		else
			return floor (e, this.root, this.root.data);
		
	}
	/**
	 * This private internal method uses recursion to traverse through the tree in search for the greatest element
	 * in the set less than or equal to the given element.
	 * @param e value given by the user and the wrapper method
	 * @param node the root of the tree or subtree to search
	 * @param temp
	 * @return E data matching the requirements or null if no such element exists
	 */
	private E floor (E e, BSTNode<E> node, E temp) {
		if (e.equals(node.data))
			return node.data;
		
		//if node.data is closer to but still less than temp replace temp
		if (e.compareTo(node.data) > 0 && e.compareTo(temp)> 0) {
			if (node.data.compareTo(temp) > 0)
				temp = node.data;
		}
		//if node.data is less than e but temp isnt
		else if (e.compareTo(node.data) > 0 && e.compareTo(temp)< 0) {
				temp = node.data;
		}
		//go right if e is bigger than current node and current node has next
		if (e.compareTo(node.data) > 0) {
			if (node.right != null)
				return floor (e, node.right, temp);
			else if (e.compareTo(temp) > 0)
				return temp;
		}
		//go left if e is less than current node and current node has next
		if (e.compareTo(node.data) < 0) {
			if (node.left != null)
				return floor (e, node.left, temp);
			else if (e.compareTo(temp) > 0)
				return temp;
		}
		return null;
	}
	/**
	 * Returns the least element in this set strictly greater than the given element or
	 * null if there is no such element.
	 * @return E reference to least element in the set strictly greater than the given element or null if there 
	 * is no such element
	 * @throws ClassCastException if the specified element cannot be compared with the elements currently in the set
	 * @throws NullPointerException if the specified element is null and this set uses natural ordering, or
	 * its comparator does not permit null elements
	 */
	public E higher (E e) {
		if (e == null || this.root == null)
			throw new NullPointerException ("The specified element is null; its comparator does not permit null elements.");
		if (e.getClass() != this.root.data.getClass())
			throw new ClassCastException ("The specified element cannot be compared with elements currently in the set.");
		else
			return higher (e, this.root, this.root.data);
	}
	private E higher (E e, BSTNode<E> node, E temp) {
		
		//if node.data is closer to but still greater than temp replace temp
		if (e.compareTo(node.data) < 0 && e.compareTo(temp)< 0) {
			if (node.data.compareTo(temp) < 0)
				temp = node.data;
		}
		//if node.data is greater than e but temp isnt
		else if (e.compareTo(node.data) < 0 && e.compareTo(temp)> 0) {
				temp = node.data;
		}
		//go right if e is greater than or equal to current node and current node has next
		if (e.compareTo(node.data) > 0 || e.equals(node.data)) {
			if (node.right != null)
				return higher (e, node.right, temp);
			else if (e.compareTo(temp) < 0)
				return temp;
		}
		//go left if e is less than current node and current node has next
		if (e.compareTo(node.data) < 0) {
			if (node.left != null)
				return higher (e, node.left, temp);
			else if (e.compareTo(temp) < 0)
				return temp;
		}
		return null;
	}
	/**
	 * Returns the last (highest) element currently in this set
	 * @return E the highest element in the tree
	 * @throws NoSuchElementException if the set is empty
	 */
	public E last() {
		if (this.root == null)
			throw new NoSuchElementException ("The set is empty");
		BSTNode<E> last = this.root;
		while (last.right != null) {
			last = last.right;
		}
		return last.data;
	}
	/**
	 * Returns the greatest element in this set strictly less than the given element
	 * or null if there is no such element.
	 * @return E reference to greatest element in the set strictly less than the given
	 * element or null if there is no exception
	 * @throws ClassCastException if the specified element cannot be compared with the elements currently in the set
	 * @throws NullPointerException if the specified element is null and this set uses natural ordering, or
	 * its comparator does not permit null elements
	 
	 */
	public E lower(E e) {
		if (e == null || this.root == null)
			throw new NullPointerException ("The specified element is null; its comparator does not permit null elements.");
		if (e.getClass() != this.root.data.getClass())
			throw new ClassCastException ("The specified element cannot be compared with elements currently in the set.");
		else
			return lower (e, this.root, this.root.data);
		
	}
	/**
	 * This internal recursive method traverses through the tree to find the greatest element strictly less than
	 * the given element
	 * @param e the given element to compare to
	 * @param node the root of the tree or subtree to search
	 * @param temp the current best fitting element
	 * @return reference to the greatest element strictly less than or greater to the given element
	 */
	private E lower (E e, BSTNode<E> node, E temp) {		
		//if node.data is closer to but still less than temp replace temp
		if (e.compareTo(node.data) > 0 && e.compareTo(temp)> 0) {
			if (node.data.compareTo(temp) > 0)
				temp = node.data;
		}
		//if node.data is less than e but temp isnt
		else if (e.compareTo(node.data) > 0 && e.compareTo(temp)< 0) {
				temp = node.data;
		}
		//go right if e is bigger than current node and current node has next
		if (e.compareTo(node.data) > 0) {
			if (node.right != null)
				return lower (e, node.right, temp);
			else if (e.compareTo(temp) > 0)
				return temp;
		}
		//go left if e is less than current node and current node has next
		if (e.compareTo(node.data) < 0 || e.equals(node.data)) {
			if (node.left != null)
				return lower (e, node.left, temp);
			else if (e.compareTo(temp) > 0)
				return temp;
		}
		return null;
	}
	
	
	//Collection methods
	/**
	 * Ensures that this collection contains the specified element.
	 * @param e data to be added to the collection
	 * @return boolean true if the element was added and false if it could not be added.
	 * @throws NullPointerException if the specified element is null 
	 * @throws ClassCastException if the class of the specified element prevents it from being added to this collection
	 */
	public boolean add(E e) {
		if (e == null)
			throw new NullPointerException ("The collection does not permit null elements");
		if (this.isEmpty() == false && e.getClass() != this.root.data.getClass())
			throw new ClassCastException ("The class of the element prevents it from being added");
		if (this.isEmpty() == false && 
				this.contains(e))
			return false;
		root = add (e, root);
		return found;
	}
	/**
	 * Internal recursive method that traverses through the node to add the data to the 
	 * appropriate location.
	 * @param e data to add
	 * @param root of the tree to add on to
	 * @return node added to the tree
	 */
	private BSTNode<E> add(E e, BSTNode<E> root) {
		if (root == null) {
			size++;
			found = true;
			return new BSTNode<E>(e);
		}
		else if (root.data.compareTo(e) < 0) {
			root.right = add(e, root.right);
		}
		else {
			root.left = add (e, root.left);
		}
		return root;
	}
	/**
	 * Removes all of the elements from this collection.
	 */
	public void clear() {
		this.root = null;
		this.size = 0;
	}
	/**
	 * Returns true if this collection contains the specified element.
	 * @param o object to be searched for
	 * @return boolean true if this collection contains the specified element or false if not.
	 */
	public boolean contains (Object o) {
		if (o == null)
			return false;
		if (o.getClass() != this.root.data.getClass())
			return false;
		
		BSTNode<E> current = this.root;
		while (current != null) {
			if (current.data.compareTo((E) o) < 0)
				current = current.right;
			else if (current.data.compareTo((E) o) > 0)
				current = current.left;
			else
				return true;
		}
		return false;
	}
	/**
	 * Returns true if this collection contains all of the elements in the specified collection.
	 * @param c collection all elements in the compared tree should contain the elements in this collection.
	 * @return boolean true if all elements in the collection are contained and false if not
	 */
	public boolean containsAll(Collection<?> c) {
		if (this == c) return true;
		if (c == null || this.root == null) return false;
		if (c.getClass() != this.root.getClass()) return false;

		if ( this.size() == c.size()) {
			for (Object e : c) {
				if(!this.contains(e)) {
					return false;
				}
			}
			return true;
		}
		return false;
		
	}
	/**
	 * Compares the specified object with this collection for equality.
	 * @return true if they are equal and false if not
	 */
	public boolean equals (Object o) {
		if (this == o) return true;
		if (o == null || this.root == null)
			return false;
		
		if (o instanceof BST<?>) {
			
			Iterator<E> thisitr = this.iterator();
			Iterator<E> oitr = ((Collection<E>) o).iterator();

			if (thisitr.hasNext() == false || oitr.hasNext() == false ) return false;
			while (thisitr.hasNext()) {
				if(!thisitr.next().equals(oitr.next()))
					return false;
			}
			return true;
		}
		return false;
	}
	/**
	 * Returns true if this collection contains no elements.
	 * @return boolean true if this collection contains no element
	 */
	public boolean isEmpty() {
		return (this.root == null);
	}
	/**
	 * Removes a single instance of the specified element from this collection if it is present. This
	 * method checks that the object is eligible to be removed and calls internal recursive methods to remove it.
	 * @param o object to be removed from the tree
	 * @return boolean true if node is found and removed and false if node does not exist.
	 * @throws NullPointerException if the specified element is null
	 * @throws ClassCastException if the elements are not of the same class
	 */
	public boolean remove (Object o) {
		if (o == null)
			throw new NullPointerException("Specified element is null");
		if (o.getClass() != this.root.data.getClass())
			throw new ClassCastException();
		root = remove((E)o, this.root);
		size--;
		return found;
	}
	/**
	 * This private internal method removes nodes with no children by returning null to
	 * replace the node if there is no left or right child.
	 * @param o value to be removed
	 * @param node root of the tree or subtree to be searched
	 * @return value replacing the current node or null if it is the node to be removed
	 */
	private BSTNode<E> remove(E o, BSTNode<E> node){
		if (node == null)
			found = false;
		else if ( o.compareTo(node.data) < 0)
			node.left = remove(o, node.left);
		else if (o.compareTo(node.data) > 0)
			node.right = remove(o, node.right);
		else {
			node = remove(node);
			found = true;
		}
		return node;
	}
	/**
	 * This private internal method takes the node to be removed. If one of the children is null it replaces the node
	 * with the other child. If both children are null it returns null to remove the node. If neither child is null the 
	 * method finds the node's predecessor and replaces it with that before rebuilding the tree underneath it.
	 * @param node to be removed
	 * @return node to take the removed node's place or null if the node itself is being removed.
	 */
	private BSTNode<E> remove(BSTNode<E> node){
		E data;
		if (node.left == null)
			return node.right;
		else if (node.right == null)
			return node.left;
		else {
			data = getPredecessor(node.left);
			node.data = data;
			node.left = remove(data, node.left);
			return node;
		}	
	}
	/**
	 * This private internal method takes the node to the left of the node to be removed and finds the highest node
	 * or the node itself if the node has no right children
	 * @param tree root of the node to be removed's left subtree
	 * @return the predecessor of the node to be removed
	 */
	private E getPredecessor(BSTNode<E> tree) {
		E data = tree.data;
		while (tree.right != null) {
			tree = tree.right;
			data = tree.data;
		}
		
		return data;		
	}
	/**
	 * Returns the number of elements in this collection.
	 * @return int the size of the collection
	 */
	public int size() {
		return this.size;
	}
	/**
	 * Returns an array containing all of the elements in this collection.
	 * @return object [] array containing all of the elements in the collection
	 */
	public Object[] toArray() {
		Iterator<E> itr = iterator();
		if (this.root == null)
			return null;
		Object [] newarray = new Object [size];
		int counter = 0;
		while(itr.hasNext()) {
			newarray[counter] = itr.next();
			counter++;
		}
		return newarray;
		
	}
	/**
	 * Returns an array containing all of the elements in this collection:
	 * the runtime type of the returned array is that of the specified array.
	 * @param type of array to be returned
	 * @return array of type specified by the parameter
	 */
	public <T> T[] toArray (T[] a) {
		if (a == null)
			return null;
		if (this.root == null)
			return null;
		Iterator<E> itr = iterator();
		T [] newarray = (T []) new Object[size];
		int counter = 0;
		while (itr.hasNext()) {
			newarray[counter] = (T) itr.next();
			counter++;
		}
		return newarray;
	}
	@Override
	/**
	 * Method unimplemented for this project.
	 */
	public boolean addAll(Collection<? extends E> c) {
		// unimplemented for project 6
		return false;
	}
	/**
	 * Method unimplemented for this project.
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		// unimplemented for project 6
		return false;
	}
	/**
	 * Method unimplemented for this project.
	 */
	@Override
	public boolean retainAll(Collection<?> c) {
		// unimplemented for project 6
		return false;
	}
}












