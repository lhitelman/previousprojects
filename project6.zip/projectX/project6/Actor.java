package project6;

	/** This class represents an Actor object. An actor object has a name. This class provides 
	 * a constructor,getter and setter methods. 
	 * @author Lily Hitelman
	 * @version 12/3/2018
	 */

	public class Actor {
		
		//stores actor name
		private String actorName;
		
		/**
		 * Constructs a new actor object.
		 * @param name name of the actor.
		 * @throws IllegalArgumentException if actor name is null or empty.
		 */
		public Actor (String name) throws IllegalArgumentException {
			if (name == null || name.length() < 1)
				throw new IllegalArgumentException("Actor 1 cannot be null.");
			setActorName(name);
		}
		
		
		
		/**
		 * This get method returns the private String variable of the actor's name.
		 * @return String actorName name of the actor object.
		 */
		public String getActorName() {
			if (actorName == null)
				return null;
			return actorName;
		}

		
		
		/**
		 * This set method sets the actor's name to the variable given to the function.
		 * @param String actorName name for the actor object.
		 * @throws IllegalArgumentException if the object is null or an empty string.
		 */
		public void setActorName(String actorName) throws IllegalArgumentException{
			
			if (actorName == null || actorName.isEmpty() )
				throw new IllegalArgumentException("Must have an Actor 1.");
			else {
				if (actorName == "")
					actorName = null;
				else {
					actorName = actorName.trim(); 
					this.actorName = actorName;
				}
			}
		}

		
	}








