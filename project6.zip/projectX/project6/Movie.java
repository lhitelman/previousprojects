package project6;

import java.util.ArrayList;


/** This class represents Movie objects. Movies have a title, year, location list, director, writer, 
 * and actor(s) (at least one). This class provides two constructors with different parameters, getters 
 * and setters for the private variables, and a method called addLocation() where one can add locations 
 * to an already existing movie (defined equal if title and year are the same).
 * The class also overrides the equals method, compareTo method, and toString method.
 * @author Lily Hitelman
 * @version 12/3/18
 * 
 */
public class Movie implements Comparable<Movie> {

	
	private String title;
	private int year;
	private ArrayList<Location> filmLocations = new ArrayList<Location>();
	private String director;
	private String writer;
	private Actor actor1 = null;
	private Actor actor2 = null; 
	private Actor actor3 = null;

	
	/**
	 * This method is the two parameter constructor. It takes a title and year.
	 * @param String title a title for the movie.
	 * @param int year the year the movie is released.
	 * @throws IllegalArgumentException if one of the set functions is unable to execute.
	 */
	public Movie (String title, int year) throws IllegalArgumentException {
		setTitle(title);
		setYear(year);
	}
	

	/**
	 * A seven parameter constructor with title, year, director, writer, and actors.
	 * It throws illegal argument exception if one of the set functions cannot execute.
	 * Only a title, year, and actor1 must not be null, the rest may be null.
	 *
	 * @param String title a title for the movie.
	 * @param int year year the movie was made.
	 * @param String director the director of the movie.
	 * @param String writer the writer of the movie.
	 * @param Actor actor1 the first actor starring in the movie.
	 * @param Actor actor2 the second actor starring in the movie.
	 * @param Actor actor3 the third actor starring in the movie.
	 * @throws IllegalArgumentException if one of the required parameters is an empty string or null.
	 */
	public Movie (String title, int year, String director, String writer, Actor actor1, 
			Actor actor2, Actor actor3) throws IllegalArgumentException {
		setTitle(title);
		setYear(year);
		setDirector(director);
		setWriter(writer);
		this.actor1 = actor1;
		if (actor1 == null)
			throw new IllegalArgumentException("Actor 1 cannot be null");
		this.actor2 = actor2;
		this.actor3 = actor3;
		
	}
	
	/**
	 * This set method sets the movie's title.
	 * @param String title title for the movie.
	 * @throws IllegalArgumentException if the title is an empty string or null.
	 */
	public void setTitle(String title) throws IllegalArgumentException{
		if (title == null || title.length() < 1)
			throw new IllegalArgumentException("Title is not valid.");
		else
			this.title = title;
		
	}
	/**
	 * This get method returns the movie's title.
	 * @return String title of the movie.
	 */
	public String getTitle() {
		return title;
	}
	
	
	
	
	
	/**
	 * This set method sets the movie's year of release. The year must be an integer between 1900 and 2020.
	 * @param int year the year the movie is released.
	 * @throws IllegalArgumentException if the year is before 1900 or after 2020.
	 */
	public void setYear(int year) throws IllegalArgumentException {
		try {
			if (year < 1900 || year > 2020) {
				throw new IllegalArgumentException("Year is not valid.");
			}
			else {
				this.year = year;
			}
		} catch (NumberFormatException ex){
			//
		} 
		
	}
		
	/**
	 * This get method returns the movie's year of release.
	 * @return int year the movie is released.
	 */
	public int getYear() {
		return year;
	}
	
	
	
	
	/**
	 * This set method sets the movie's director.
	 * @param String dir the director of the movie.
	 */
	public void setDirector(String dir) {
		this.director = dir;
	}
	
	
	
	/**
	 * This get method returns the movie's director.
	 * @return String the movie's director.
	 */
	public String getDirector() {
		return director;
	}
	
	
	
	
	/**
	 * This set method sets the movie's writer.
	 * @param String writer writer of the movie
	 */
	public void setWriter(String writer) {
		this.writer = writer;
	}
	
	/**
	 * This get method returns the movie's writer.
	 * @return String the writer of the movie.
	 */
	public String getWriter() {
		return writer;
	}
	
	
	

	
	
	/**
	 * This get method returns the first actor's name.
	 * @return String actor name the first actor object's name.
	 */
	public String getActor1() {
		if (actor1 != null)
			return actor1.getActorName();
		else 
		{
			return null; 
		}
	}
	
	
	/**
	 * This set method returns actor2's name.
	 * @return String the second actor object's name
	 */
	public String getActor2 () {
		if (actor2 != null)
			return actor2.getActorName();
		else 
		{
			return null; 
		}
	}

	
	/**
	 * This get method returns actor3's name.
	 * @return String the third actor object's name
	 */
	public String getActor3 () {
		if (actor3 != null)
			return actor3.getActorName();
		else 
		{
			return null; 
		}
	}
	
	
	
	
	
	/**
	 * This method adds a location (and fun fact if it exists) to the movie. If the location doesn't exist, 
	 * it throws an illegal argument exception because every Location requires a location name, and every
	 * movie requires a location.
	 * @param String newLoc a string describing a location where a movie was filmed.
	 * @throws IllegalArgumentException if the location is an empty string or null.
	 */
	public void addLocation (Location newLoc) throws IllegalArgumentException {
		if (newLoc == null)
			throw new IllegalArgumentException("Cannot add null location.");
		filmLocations.add(newLoc);
		
	}
	
	
	
	
	
	/**
	 * This method overrides the default toString method. It returns a formatted string 
	 * that presents the movie's title, director, writer, actors, locations, and fun facts.
	 * @return String detailing the movie specifications
	 */
	@Override
	public String toString() {	
		StringBuilder locations = new StringBuilder("");
		StringBuilder starring = new StringBuilder("");
		locations.append("filmed on location at: \n");
		String title = "\n\n" + this.getTitle() + " (" + this.getYear() + ")\n---------------------------------\n";
		String director = String.format("%-30s: %s\n", "director", this.getDirector());
		String writer = String.format("%-30s: %s\n", "writer", this.getWriter());
		starring.append("starring                      : ");
		starring.append(actor1.getActorName());
		try {
			if (actor2.getActorName()!= null) {
				starring.append(", " + actor2.getActorName());
				if (actor3.getActorName()!= null)
					starring.append(", " + actor3.getActorName() );
			}
		}catch (NullPointerException n) {}
		starring.append("\n");
		if (!filmLocations.isEmpty()) {
			for (Location l: filmLocations) {
				locations.append("\t" + l.getLocation() + "\n");
			}
		}
		
		return title + director + writer + starring.toString() + locations.toString();
		
	}	
	
	
	
	
	
	/** (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 * 
	 * This method overrides the Object equals method.
	 * Movies are equal if they have the same title and year. It takes in a movie object and
	 * compares the title and year to the movie it was called on.

	 */
	@Override
	public boolean equals (Object obj) {
		if (obj == null || this == null)
			return false;
		if (obj.getClass() != this.getClass())
			return false;
		if (this.title.equalsIgnoreCase(((Movie)obj).getTitle()) && this.year == ((Movie)obj).getYear())
			return true;
		else
			return false;
		
	}


	
	/** (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 * 
	 * This method sorts first chronologically by year, then alphabetically by title.
	 * movie1.compareTo(movie2) returns 1 if movie1 is newer (year is bigger)
	 * @return int -1 if movie1 is older (year is smaller)
	 * @return int 0 if they're made in the same year.
	 */
	@Override
	public int compareTo(Movie mov) {
		if (this.year < mov.year)
			return -1;
		else if (this.year > mov.year)
			return 1;	

		else if (this.year == mov.year) {
			return this.title.toLowerCase().compareTo(mov.title.toLowerCase());
		
		}
		
		return 0;
		
	}
	
	
	
}


