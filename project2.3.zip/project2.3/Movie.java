package project2;

import java.util.ArrayList;


/** This class represents Movie objects. Movies have a title, year, location list, director, writer, and actor(s). 
 * This class provides two constructors, getters and setters for the private variables, 
 * and a method called addLocation() where one can add locations to an already existant movie (same title and year).
 * The class also overrides an equals method, compareTo method, and toString method.
 * @author Lily Hitelman
 * @version 10/4/18
 * 
 */
public class Movie implements Comparable<Movie> {

	private String title;
	private int year;
	private ArrayList<Location> filmLocations = new ArrayList<Location>();
	private String director;
	private String writer;
	private Actor actor1, actor2, actor3;

	
	/**
	 * two parameter constructor (title and year)
	 * @param title - a title for the movie
	 * @param year - the year the movie is released
	 * @throws IllegalArgumentException
	 */
	public Movie (String title, int year) throws IllegalArgumentException {
		setTitle(title);
		setYear(year);
	}

	/**
	 * A seven parameter constructor with title, year, director, writer, and actors.
	 * It throws illegal argument exception if one of the set functions cannot execute.
	 * Only a title, year, and actor1 aren't allowed to be null, the rest may be null.
	 *
	 * @param title - a title for the movie
	 * @param year - year the movie was made
	 * @param director - the director of the movie
	 * @param writer - the writer of the movie
	 * @param actor1 - the first actor starring in the movie
	 * @param actor2 - the second actor starring in the movie
	 * @param actor3 - the third actor starring in the movie
	 * @throws IllegalArgumentException if one of the required parameters is not legal (empty string or null).
	 */
	public Movie (String title, int year, String director, String writer, Actor actor1, 
			Actor actor2, Actor actor3) throws IllegalArgumentException {
		setTitle(title);
		setYear(year);
		setDirector(director);
		setWriter(writer);
		this.actor1 = actor1;
		this.actor2 = actor2;
		this.actor3 = actor3;
		
	}
	
	/**
	 * This method sets the movie's title.
	 * @param title - title for the movie
	 * @throws IllegalArgumentException if the title is an empty string or null.
	 */
	public void setTitle(String title) throws IllegalArgumentException{
		if (title.length() < 1 || title == null)
			throw new IllegalArgumentException("Title is not valid.");
		else
			this.title = title;
		
	}
	/**
	 * This method returns the movie's title.
	 * @return title - title of the movie
	 */
	public String getTitle() {
		return title;
	}
	
	
	
	
	
	/**
	 * This method sets the movie's year of release.
	 * @param year - the year the movie is released
	 * @throws IllegalArgumentException if the year is before 1900 or after 2020
	 */
	public void setYear(int year) throws IllegalArgumentException {
		try {
			if (year < 1900 || year > 2020) {
				throw new IllegalArgumentException("Year is not valid.");
			}
			else {
				this.year = year;
			}
		} catch (NumberFormatException ex){
			System.out.println("Year is not valid for: " + getTitle());
		} 
		
	}
		
	/**
	 * This method returns the movie's year of release.
	 * @return year - year the movie is released
	 */
	public int getYear() {
		return year;
	}
	
	
	
	
	/**
	 * This method sets the movie's director.
	 * @param dir - the director of the movie
	 */
	public void setDirector(String dir) {
		this.director = dir;
	}
	
	/**
	 * This method returns the movie's director.
	 * @return director - the movie's director.
	 */
	public String getDirector() {
		return director;
	}
	
	
	
	
	/**
	 * This method sets the movie's writer.
	 * @param writer - writer of the movie
	 */
	public void setWriter(String writer) {
		this.writer = writer;
	}
	
	/**
	 * This method returns the movie's writer.
	 * @return writer - the writer of the movie.
	 */
	public String getWriter() {
		return writer;
	}
	
	
	

	
	
	/**
	 * This method returns the first actor's name.
	 * @return actor name - the first actor object's name.
	 */
	public String getActor1() {
		if (actor1 != null)
			return actor1.getActorName();
		else 
		{
			System.out.println(this.title);
			return null; 
		}
	}
	
	
	

	
	/**
	 * This method returns actor2's name.
	 * @return name - the second actor object's name
	 */
	public String getActor2 () {
		return actor2.getActorName();
	}
	
	
	

	
	/**
	 * This method returns actor3's name.
	 * @return name  - the second actor object's name
	 */
	public String getActor3 () {
		return actor3.getActorName();
	}
	
	
	/**
	 * This method adds a location (and fun fact if it exists) to the movie. If the location doesn't exist, 
	 * it throws an illegal argument exception because every movie object requires a location.
	 * @param loc - a string describing a location where a movie was filmed
	 * @param funFacts - a string containing fun facts about the given location
	 * @throws IllegalArgumentException if the location is an empty string or null.
	 */
	public void addLocation (Location newLoc) throws IllegalArgumentException {
			filmLocations.add(newLoc);
		
	}
	
	
	/**
	 * This method overrides the default toString method. It returns
	 * a formatted string.
	 * @return String detailing the movie specifications
	 */
	@Override
	public String toString() {	
		StringBuilder locations = new StringBuilder("");
		locations.append("filmed on location at: \n");
		String title = "\n\n" + this.getTitle() + " (" + this.getYear() + ")\n---------------------------------\n";
		String director = String.format("%-30s: %s\n", "director", this.getDirector());
		String writer = String.format("%-30s: %s\n", "writer", this.getWriter());
		String starring = " ";
		if (actor1!= null && actor2 != null && actor3 != null) {
			starring = String.format("%-30s: %s, %s, %s\n", "starring", actor1.getActorName(), 
				actor2.getActorName(), actor3.getActorName());
		}
		if (actor1!= null && actor2 != null) {
			starring = String.format("%-30s: %s, %s\n", "starring", actor1.getActorName(), 
					actor2.getActorName());
		}
		if (actor1 !=null) {
			starring = String.format("%-30s: %s\n", "starring", actor1.getActorName());
		}
		
		
		for (Location l: filmLocations) {
			locations.append("\t" + l.getLocation() + "\n");
		}
		
		return title + director + writer + starring + locations.toString();
		
	}	
	
	
	
	
	
	/** (non-Javadoc)
	 * Movies are equal if they have the same title and year.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals (Object obj) {
		
		if (this.title.equalsIgnoreCase(((Movie)obj).getTitle()) && this.year == ((Movie)obj).getYear())
			return true;
		else
			return false;
		
	}


	
	/** (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 * 
	 * This method sorts first chronologically by year, then alphabetically by title.
	 * movie1.compareTo(movie2) returns 1 if movie1 is newer (year is bigger)
	 * returns -1 if movie1 is older (year is smaller)
	 * returns 0 if they're made in the same year.
	 */
	@Override
	public int compareTo(Movie mov) {
		if (this.year < mov.year)
			return -1;
		else if (this.year > mov.year)
			return 1;	

		else if (this.year == mov.year) {
			int compare = this.title.toLowerCase().compareTo(mov.title.toLowerCase());
			if ( compare < 0)
				return -1;
			else if (compare > 0)
				return 1;
			else if (compare == 0)
				return 0;			
		}
		
		return 0;
		
	}
	
	
	
}


