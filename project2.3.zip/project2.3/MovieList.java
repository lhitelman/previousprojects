package project2;

import java.util.ArrayList;
import java.util.Collections; 


/** This class represents MovieList objects. MovieLists extends ArrayList
 * and are essentially arraylists of movie objects.
 * This class provides two methods to search for matching titles and actors
 * in the program's main movie list. It also provides a toString method that
 * returns a list of all the movies in the referenced list.
 * @author Lily Hitelman
 * @version 10/4/18
 * 
 */
public class MovieList extends ArrayList<Movie> {

	/**
	 * default constructor that creates an empty movielist object
	 * 
	 */
	public MovieList () {
		//ArrayList<Movie> ml = new ArrayList<> ();
	}
	
	/**
	 * This method searches through the list from which the function is called
	 * to find titles that contain the given keyword.
	 * @param keyword - given by the user to search for titles that contain this keyword
	 * @return MovieList - a list of movies that have titles that contain the keyword
	 */
	public MovieList getMatchingTitles (String keyword) {
		//return a list of movie objects whose titles contain the keyword as a substring
		if (keyword == null || keyword.length() == 0)
			return null;
		String keywordLower = keyword.toLowerCase();
		MovieList matchingTitles = new MovieList ();
		for (Movie m: this) {
			String title = m.getTitle();
			String titleLower = title.toLowerCase();
			if (titleLower.contains(keywordLower)) {
				matchingTitles.add(m);
			}
		}
		
		Collections.sort(matchingTitles);
		
		if (matchingTitles.size() == 0)
			return null;
		else
			return matchingTitles;
	}
	
	
	/**
	 * This method searches through the list from which the function is called
	 * to find actor names that contain the given keyword.
	 * @param keyword - given by the user, searches for movie actors containing this keyword
	 * @return MovieList - a list of movies that contain actor names that contain the keyword
	 */
	public MovieList getMatchingActor (String keyword) {
		//return a list of movie object whose actors' names contain the keyword as a substring
		if (keyword == null || keyword.length() == 0)
			return null;
		String keywordLower = keyword.toLowerCase();
		MovieList matchingActors = new MovieList ();
		for (Movie m: this) {
			
			String actor1 = m.getActor1();
			String actor2 = null;
			String actor2Lower = null;
			String actor3 = null;
			String actor3Lower = null;
			
			String actor1Lower = actor1.toLowerCase();
			if (actor1Lower.contains(keywordLower))
				matchingActors.add(m); 
			try {
				actor2 = m.getActor2();
				actor2Lower = actor2.toLowerCase();
				if(actor2Lower.contains(keywordLower))
					matchingActors.add(m);
			}catch (NullPointerException ex) {	
			}
			try {
				actor3 = m.getActor3();
				actor3Lower = actor3.toLowerCase();
				if(actor3Lower.contains(keywordLower))
					matchingActors.add(m);
			}catch (NullPointerException ep) {	
			}

		}
		
		Collections.sort(matchingActors);
		
		if (matchingActors.size() == 0) 
			return null;
		else
			return matchingActors;
	}
	

	
	/**
	 * This method overrides the default toString method. It returns
	 * a formatted string.
	 * @return String - detailing the movie specifications.
	 */
	@Override
	public String toString() {
		//return a string containing a semicolon and a space separated list of the titles of the movie objects
		
		StringBuilder ts = new StringBuilder("");
		ts.append("\"");
		
		for (int i = 0; i < this.size(); i++) {
			String title = this.get(i).getTitle();
			ts.append(title);
			while (i < this.size()-1) {
				ts.append("; ");
			}
		}
		ts.append("\"");

		return ts.toString();
	}

	
}





